from __future__ import unicode_literals

from django.apps import AppConfig


class DjangoAppConfig(AppConfig):
    name = 'django_app'
